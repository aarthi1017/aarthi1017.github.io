import machine
import time
import urequests
import network

# WiFi and ThingSpeak configuration
WIFI_SSID = "Wokwi-GUEST"
WIFI_PASSWORD = ""
THINGSPEAK_API_KEY = "14UWOU7T2MK6BB7N"
THINGSPEAK_CHANNEL_ID = "2321849"

# Define IR sensor pin
ir_sensor_pin = 22

# Function to read IR sensor data
def read_ir_sensor():
    ir_sensor = machine.Pin(ir_sensor_pin, machine.Pin.IN)
    return ir_sensor.value()

# Function to send data to ThingSpeak
def send_to_thingspeak(data):
    url = "https://api.thingspeak.com/update"
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    payload = "api_key={}&field1={}".format(THINGSPEAK_API_KEY, data)

    try:
        response = urequests.post(url, headers=headers, data=payload)
        if response.status_code == 200:
            print("Data sent to ThingSpeak successfully")
        else:
            print("Failed to send data to ThingSpeak. Status code:", response.status_code)
        response.close()
    except Exception as e:
        print("Failed to send data to ThingSpeak:", e)

# Function to check WiFi connection status
def check_wifi_status():
    sta = network.WLAN(network.STA_IF)
    sta.active(True)
    sta.connect(WIFI_SSID, WIFI_PASSWORD)
    while not sta.isconnected():
        pass
    print("Connected to WiFi")

# Connect to WiFi
check_wifi_status()

# Main loop
while True:
    try:
        noise_level = read_ir_sensor()
        print("Noise Level:", noise_level)
        
        # Send data to ThingSpeak
        send_to_thingspeak(noise_level)
        
    except KeyboardInterrupt:
        break
